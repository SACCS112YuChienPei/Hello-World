/*Santa Ana College
 * CMPR 112_Assignment #1
 * Stuent Name: Chien-Pei M. Yu
 */
package java_welcome;

/**
 *
 * @author LeonCPYu
 */
public class Java_Welcome {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    System.out.println("Hello World!");    
    }
    
}
